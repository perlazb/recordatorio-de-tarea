<template>
  <div class="login-container">
    <h3 class="title">Iniciar Sesión</h3>
    <div class="card-body">
      <div class="input-group">
        <label for="email">Email</label>
        <input type="email" id="email" v-model="email" />
        <span v-if="emailError" class="error-message">{{ emailError }}</span>
      </div>
      <div class="input-group">
        <label for="password">Contraseña</label>
        <input type="password" id="password" v-model="password" />
        <span v-if="passwordError" class="error-message">{{ passwordError }}</span>
      </div>
      <button @click="login">Ingresar</button>
      <span v-if="error" class="error-message">{{ error }}</span>
    
    </div>
  </div>
</template>

<script>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { useTaskStore } from '../stores/taskStore'; // Importa el taskStore para registrar al usuario

export default {
  setup() {
    const email = ref('');
    const password = ref('');
    const error = ref('');
    const emailError = ref('');
    const passwordError = ref('');
    const router = useRouter();
    const taskStore = useTaskStore(); // Accede al taskStore

    const validateEmail = () => {
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!email.value) {
        emailError.value = 'El email es requerido';
        return false;
      } else if (!emailPattern.test(email.value)) {
        emailError.value = 'El formato del email es inválido';
        return false;
      }
      emailError.value = '';
      return true;
    };

    const validatePassword = () => {
      if (!password.value) {
        passwordError.value = 'La contraseña es requerida';
        return false;
      } else if (password.value.length < 6) {
        passwordError.value = 'La contraseña debe tener al menos 6 caracteres';
        return false;
      }
      passwordError.value = '';
      return true;
    };

    const login = () => {
      const isEmailValid = validateEmail();
      const isPasswordValid = validatePassword();

      if (isEmailValid && isPasswordValid) {
        const token = true;
        localStorage.setItem('token', token);
        
        // Registra al usuario al hacer login
        taskStore.registerUser({ email: email.value }); // Llama a registerUser con el email del usuario

        // Redirige a la página de tareas
        router.push('/task');
      }
    };

    return {
      email,
      password,
      error,
      emailError,
      passwordError,
      login,
    };
  },
};
</script>


<style scoped>
.login-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh; /* Full viewport height */
  background-color: #f0f8ff; /* Light blue background */
  font-family: 'Comic Sans MS', cursive, sans-serif; /* Fun font style */
  padding: 0 20px; /* Add some padding on the sides */
}

.title {
  font-size: 2.5rem;
  color: #ffcc00; /* Bright yellow for the title */
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
  margin-bottom: 20px;
}

.card-body {
  background-color: #ffffff; /* White card background */
  border-radius: 15px; /* Rounded corners */
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
  padding: 30px;
  width: 100%; /* Full width */
  max-width: 400px; /* Max width to maintain the card shape */
  text-align: center;
}

.input-group {
  margin-bottom: 15px;
}

label {
  display: block;
  margin-bottom: 5px;
  color: #333; /* Dark text for labels */
}

input {
  width: 100%;
  padding: 10px;
  border-radius: 10px; /* Rounded input fields */
  border: 2px solid #ffcc00; /* Yellow border */
  font-size: 1rem;
}

input:focus {
  outline: none;
  border-color: #00ccff; /* Blue border on focus */
}

button {
  padding: 10px;
  background-color: #ff5733; /* Bright red-orange for button */
  color: white;
  font-size: 1.2rem;
  border: none;
  border-radius: 10px; /* Rounded button */
  cursor: pointer;
  transition: background-color 0.3s;
}

button:hover {
  background-color: #c70039; /* Darker red on hover */
}

.error-message {
  color: #ff3333; /* Red for error messages */
  font-size: 0.9rem;
  margin-top: 5px;
}
</style>


