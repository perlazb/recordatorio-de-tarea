<template>
  <div class="task-manager-container">
    <div class="task-list">
      <h2>Administrar Tareas</h2>
      <form @submit.prevent="addTask" class="task-form">
        <input v-model="description" placeholder="descripción" required />
        <input type="date" v-model="dueDate" required />
        <button type="submit">Agregar Tarea</button>
      </form>

      <p v-if="message" class="success-message">{{ message }}</p>

      <h3>Tareas</h3>
      <ul class="task-items">
        <li v-for="task in userTasks" :key="task.id" class="task-item">
          <div class="task-info">
            <span class="task-description">{{ task.description }}</span>
            <span class="task-due">{{ task.dueDate }}</span>
            <span class="task-status">{{ task.status }}</span>
          </div>
          <div class="task-actions">
            <button @click="updateTaskStatus(task.id)">
              {{ task.status === 'completado' ? 'En Proceso' : 'Completado' }}
            </button>
            <button @click="confirmDeleteTask(task.id)">Borrar</button>
          </div>
        </li>
      </ul>
    </div>

    <div class="user-list">
      <h2>Usuarios Registrados</h2>
      <ul>
        <li v-for="user in registeredUsers" :key="user.email">
          {{ user.email }}
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import { ref, computed } from 'vue';
import { useTaskStore } from '../stores/taskStore';

export default {
  setup() {
    const taskStore = useTaskStore();
    const userId = 'user1';
    const description = ref('');
    const dueDate = ref('');
    const message = ref('');

    const userTasks = computed(() => taskStore.userTasks[userId] || []);
    const registeredUsers = computed(() => taskStore.registeredUsers);

    function addTask() {
      const newTask = {
        id: Date.now(),
        description: description.value,
        dueDate: dueDate.value,
        status: 'en proceso',
      };
      taskStore.addTask(userId, newTask);
      resetForm();
      showMessage('Creada exitosamente');
    }

    function updateTaskStatus(taskId) {
      const task = userTasks.value.find(t => t.id === taskId);
      if (task) {
        const nextStatus = task.status === 'completado' ? 'en progreso' : 'completado';
        taskStore.updateTask(userId, taskId, { status: nextStatus });
      }
    }

    function confirmDeleteTask(taskId) {
      const confirmed = confirm("¿Estás seguro de que deseas eliminar esta tarea?");
      if (confirmed) {
        deleteTask(taskId);
      }
    }

    function deleteTask(taskId) {
      taskStore.deleteTask(userId, taskId);
    }

    function resetForm() {
      description.value = '';
      dueDate.value = '';
    }

    function showMessage(msg) {
      message.value = msg;
      setTimeout(() => {
        message.value = '';
      }, 3000);
    }

    return {
      description,
      dueDate,
      userTasks,
      registeredUsers,
      message,
      addTask,
      updateTaskStatus,
      confirmDeleteTask,
    };
  },
};
</script>

<style scoped>
.task-manager-container {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  background-color: #f0f8ff; /* Light sky blue background */
  padding: 20px;
  border-radius: 15px; /* Rounded corners */
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
  height: 100vh; /* Full height */
}

.task-list {
  flex: 1;
  margin-right: 20px;
  color: #2c3e50; /* Dark text color */
}

h2, h3 {
  text-align: center;
  font-family: 'Comic Sans MS', cursive, sans-serif; /* Fun font */
  color: #ffcc00; /* Bright yellow */
  text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
}

.task-form {
  display: flex;
  flex-direction: column;
  background-color: #34495e; /* Dark card background */
  padding: 20px;
  border-radius: 10px; /* Rounded corners */
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  margin-bottom: 20px;
}

input {
  margin-bottom: 15px;
  padding: 12px;
  border-radius: 5px;
  border: 2px solid #1abc9c; /* Teal border */
  background-color: #ecf0f1; /* Light input background */
  font-size: 16px;
  color: #2c3e50; /* Dark text color */
}

input:focus {
  outline: none;
  border-color: #ff5733; /* Highlight border on focus */
}

button {
  padding: 12px;
  background-color: #ff5733; /* Bright red-orange */
  color: white;
  font-weight: bold;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s;
}

button:hover {
  background-color: #c70039; /* Darker red on hover */
}

.task-items {
  list-style: none;
  padding: 0;
}

.task-item {
  background-color: #34495e; /* Dark item background */
  margin-bottom: 10px;
  padding: 15px;
  border-radius: 8px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1);
}

.task-info {
  flex: 1;
  display: flex;
  justify-content: space-between;
  margin-right: 20px;
}

.task-description {
  font-size: 16px;
  font-weight: bold;
  color: #ecf0f1; /* Light text color */
}

.task-due, .task-status {
  font-size: 14px;
  color: #bdc3c7; /* Lighter color */
}

.task-actions {
  display: flex;
  gap: 10px;
}

.success-message {
  color: #2ecc71; /* Green for success messages */
  text-align: center;
  font-weight: bold;
  margin-top: 10px;
}

.user-list {
  width: 250px;
  background-color: #34495e; /* Dark user list background */
  padding: 20px;
  border-radius: 10px; /* Rounded corners */
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  color: #ecf0f1; /* Light text color */
}

.user-list ul {
  list-style: none;
  padding: 0;
}

.user-list li {
  padding: 10px 0;
  border-bottom: 1px solid #7f8c8d;
  color: #ecf0f1; /* Light text color */
  font-family: 'Comic Sans MS', cursive, sans-serif; /* Fun font */
}
</style>

