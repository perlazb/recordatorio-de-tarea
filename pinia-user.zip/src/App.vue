<template>
  <router-view />
</template>

<script>
export default {
  name: 'App',
};
</script>

<style>
body {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh; /* Full viewport height */
  margin: 0;
  background-color: #f0f8ff; /* Soft background color */
  background-image: url('https://wallpapers.com/images/hd/adventure-time-inhabitants-of-ooo-2qmbaaawho7a0j7z.webp');
  background-size: cover; /* Cover the entire viewport */
  background-position: center; /* Center the image */
  background-repeat: no-repeat; /* Prevent repeating the image */
}


html, #app {
  height: 100%;
}
</style>



