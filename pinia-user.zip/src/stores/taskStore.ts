// stores/taskStore.ts
import { defineStore } from 'pinia';

export const useTaskStore = defineStore('task', {
  state: () => ({
    tasks: [], // Almacena las tareas
    userTasks: {}, // Almacena tareas por usuario
    registeredUsers: [] as Array<{ email: string }> // Almacena los usuarios registrados
  }),
  actions: {
    addTask(userId: string, task: any) {
      if (!this.userTasks[userId]) {
        this.userTasks[userId] = [];
      }
      this.userTasks[userId].push(task);
    },
    updateTask(userId: string, taskId: string, updatedTask: any) {
      const index = this.userTasks[userId].findIndex(task => task.id === taskId);
      if (index !== -1) {
        this.userTasks[userId][index] = { ...this.userTasks[userId][index], ...updatedTask };
      }
    },
    deleteTask(userId: string, taskId: string) {
      this.userTasks[userId] = this.userTasks[userId].filter(task => task.id !== taskId);
    },
    registerUser(user: { email: string }) {
      // Solo agrega el usuario si no está ya registrado
      if (!this.registeredUsers.some(u => u.email === user.email)) {
        this.registeredUsers.push(user);
      }
    },
    getRegisteredUsers() {
      return this.registeredUsers; // Devuelve la lista de usuarios registrados
    }
  }
});
